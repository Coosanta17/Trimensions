
# Trimensions

A minecraft datapack collaboration.

  

This is a long term project for Minecraft Java Edition (recommended in servers) for those who have done everything in default Minecraft

This pack adds 3 new dimensions, the Sky Mountains, Deep Caverns, and The Cursed Gardens.

You can see some screenshots below:
![It Hasn't been finished yet!](https://github.com/Coosanta17/Trimensions/raw/main/Reasources/COMING_SOOOOON!!.png)
  
also has 30+ biomes!

Battle powerful bosses!

and Many new Items and weapons.

#### THIS PACK IS STILL IN PROGRESS
about 50% thru and hopefully first Beta release on 1st of January 2022

THERE IS MORE! but i can't be bother lol

Come join us on discord!
**[https://discord.gg/wQtqZjYXqa](https://discord.gg/wQtqZjYXqa "https://discord.gg/wQtqZjYXqa")**

If you want to contribute to the pack dm me thru discord @ `Coosanta#7004` or join the server and ask
